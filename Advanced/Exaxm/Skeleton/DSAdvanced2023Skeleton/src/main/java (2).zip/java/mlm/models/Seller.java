package mlm.models;

public class Seller {
    public String id;
    public int earnings;

    public Seller(String id) {
        this.id = id;
        earnings = 0;
    }
}
