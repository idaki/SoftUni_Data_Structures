package mlm.core;

import mlm.models.Seller;

import java.util.Collection;

public class MLMServiceImpl implements MLMService {
    @Override
    public void addSeller(Seller seller) {

    }

    @Override
    public void hireSeller(Seller parent, Seller newHire) {

    }

    @Override
    public boolean exists(Seller seller) {
        return false;
    }

    @Override
    public void fire(Seller seller) {

    }

    @Override
    public void makeSale(Seller seller, int amount) {

    }

    @Override
    public Collection<Seller> getByProfits() {
        return null;
    }

    @Override
    public Collection<Seller> getByEmployeeCount() {
        return null;
    }

    @Override
    public Collection<Seller> getByTotalSalesMade() {
        return null;
    }
}
