package solar.core;

import solar.models.Inverter;
import solar.models.PVModule;

import java.util.Collection;

public class SolarServiceImpl implements SolarService {
    @Override
    public void addInverter(Inverter inverter) {

    }

    @Override
    public void addArray(Inverter inverter, String arrayId) {

    }

    @Override
    public void addPanel(Inverter inverter, String arrayId, PVModule pvModule) {

    }

    @Override
    public boolean containsInverter(String id) {
        return false;
    }

    @Override
    public boolean isPanelConnected(PVModule pvModule) {
        return false;
    }

    @Override
    public Inverter getInverterByPanel(PVModule pvModule) {
        return null;
    }

    @Override
    public void replaceModule(PVModule oldModule, PVModule newModule) {

    }

    @Override
    public Collection<Inverter> getByProductionCapacity() {
        return null;
    }

    @Override
    public Collection<Inverter> getByNumberOfPVModulesConnected() {
        return null;
    }

    @Override
    public Collection<PVModule> getByWattProduction() {
        return null;
    }
}
