import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class PersonCollectionSlowImpl implements PersonCollection {

    private final List<Person> persons = new ArrayList<>();

    @Override
    public boolean add(String email, String name, int age, String town) {
        if (find(email) != null) {
            return false;
        }

        Person person = new Person(email, name, age, town);
        persons.add(person);
        return true;
    }

    @Override
    public int getCount() {
        return persons.size();
    }

    @Override
    public boolean delete(String email) {
        Person person = find(email);
        if (person == null) {
            return false;
        }

        persons.remove(person);
        return true;
    }

    @Override
    public Person find(String email) {
        return persons.stream()
                .filter(person -> person.getEmail().equals(email))
                .findFirst()
                .orElse(null);
    }

    @Override
    public Iterable<Person> findAll(String emailDomain) {
        return persons.stream()
                .filter(person -> person.getEmail().endsWith("@" + emailDomain))
                .sorted(Comparator.comparing(Person::getEmail))
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Person> findAll(String name, String town) {
        return persons.stream()
                .filter(person -> person.getName().equals(name) && person.getTown().equals(town))
                .sorted(Comparator.comparing(Person::getEmail))
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Person> findAll(int startAge, int endAge) {
        return persons.stream()
                .filter(person -> person.getAge() >= startAge && person.getAge() <= endAge)
                .sorted(Comparator.comparing(Person::getAge).thenComparing(Person::getEmail))
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Person> findAll(int startAge, int endAge, String town) {
        return persons.stream()
                .filter(person -> person.getTown().equals(town) && person.getAge() >= startAge && person.getAge() <= endAge)
                .sorted(Comparator.comparing(Person::getAge).thenComparing(Person::getEmail))
                .collect(Collectors.toList());
    }
}