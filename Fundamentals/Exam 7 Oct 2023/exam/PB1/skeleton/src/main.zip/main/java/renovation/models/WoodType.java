package renovation.models;

public enum WoodType {
    OAK, CHERRY, WALNUT
}
