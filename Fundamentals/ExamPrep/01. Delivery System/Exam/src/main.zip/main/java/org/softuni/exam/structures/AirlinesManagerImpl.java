package org.softuni.exam.structures;

import org.softuni.exam.entities.Airline;
import org.softuni.exam.entities.Flight;

import java.util.*;
import java.util.stream.Collectors;

public class AirlinesManagerImpl implements AirlinesManager {

    private Map<String, Airline> airlines;
    private Map<String, List<Flight>> flightsByAirline;
    private Map<String, List<Flight>> completedFlights;

    public AirlinesManagerImpl() {
        this.airlines = new LinkedHashMap<>();
        this.flightsByAirline = new LinkedHashMap<>();
        this.completedFlights = new HashMap<>();
    }

    @Override
    public void addAirline(Airline airline) {
        airlines.putIfAbsent(airline.getId(), airline);
    }

    @Override
    public void addFlight(Airline airline, Flight flight) {
        if (flightsByAirline.containsKey(airline.getId())) {
            flightsByAirline.put(airline.getId(), new ArrayList<>());
        }
        flightsByAirline.get(flight.getId()).add(flight);

    }

    @Override
    public boolean contains(Airline airline) {

        return airlines.containsKey(airline.getId());
    }

    @Override
    public boolean contains(Flight flight) {


        return flightsByAirline.values()
                .stream()
                .anyMatch(flightList -> flightList.contains(flight));
    }

    @Override
    public void deleteAirline(Airline airline) throws IllegalArgumentException {
        if (!airlines.containsKey(airline.getId())) {
            throw new IllegalArgumentException();
        }
        airlines.remove(airline.getId());
    }

    @Override
    public Iterable<Flight> getAllFlights() {
        return flightsByAirline.values()
                .stream()
                .flatMap(List::stream) //
                .collect(Collectors.toList());
    }

    @Override
    public Flight performFlight(Airline airline, Flight flight) throws IllegalArgumentException {
        if (!flightsByAirline.containsKey(airline.getId())
                || !flightsByAirline.get(flightsByAirline.get(airline.getId())).contains(airline)) {
            throw new IllegalArgumentException();
        }
        Flight currentFlight = flightsByAirline.get(airline.getId())
                .stream()
                .filter(f -> f.getId().equals(flight.getId()))
                .findFirst()
                .orElse(null);
        currentFlight.setCompleted(true);

        if (!completedFlights.containsKey(airline.getId())) {
            completedFlights.put(airline.getId(), new ArrayList<>());
        }
        completedFlights.get(airline.getId()).add(currentFlight);

        return currentFlight;
    }

    @Override
    public Iterable<Flight> getCompletedFlights() {
        return completedFlights.values()
                .stream()
                .flatMap(List::stream) //
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Flight> getFlightsOrderedByNumberThenByCompletion() {
        List<Flight> allFlights =  flightsByAirline.values().stream()
                .flatMap(Collection::stream)
                .collect(Collectors.toList());


        return allFlights.stream().sorted(Comparator.comparing(Flight::getNumber)
                        .thenComparing(Flight::isCompleted))
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Airline> getAirlinesOrderedByRatingThenByCountOfFlightsThenByName() {

        return   airlines.values()
                .stream()
                .sorted(Comparator.comparing(Airline::getRating)
                        .thenComparing(airline -> flightsByAirline.get(airline.getId()).size())
                        .thenComparing(Comparator.comparing(Airline::getName)))
                .collect(Collectors.toList());

    }

    @Override
    public Iterable<Airline> getAirlinesWithFlightsFromOriginToDestination(String origin, String destination) {
        return null;
    }
}
