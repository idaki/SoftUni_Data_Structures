package implementations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ReversedList<E> implements Iterable<E> {

    public static final int INITIAL_CAPACITY = 2;
    private Object[] elements;
    private int size;

    public ReversedList() {
        this.elements = new Object[INITIAL_CAPACITY];
        this.size = 0;
    }

    public void add(E element) {
        if (this.size == this.elements.length) {
            this.grow();
        }
        this.elements[this.size++] = element;
    }

    public int size() {
        return this.size;
    }

    public int capacity() {
        return this.elements.length;
    }

    public E get(int index) {
        this.ensureIndex(index);
        return (E) this.elements[this.size - index - 1];
    }

    public E removeAt(int index) {
        this.ensureIndex(index);

        int indexToRemove = this.size - index - 1;
        E element = (E) this.elements[indexToRemove];
        this.elements[indexToRemove] = null;

        for (int i = indexToRemove; i < this.size - 1; i++) {
            this.elements[i] = this.elements[i + 1];
        }
        this.size--;

        // Check if the capacity should be reduced
        if (this.size < this.elements.length / 2 && this.elements.length > INITIAL_CAPACITY) {
            this.shrink();
        }

        return element;
    }

    private void grow() {
        this.elements = Arrays.copyOf(this.elements, this.elements.length * 2);
    }

    private void shrink() {
        this.elements = Arrays.copyOf(this.elements, Math.max(INITIAL_CAPACITY, this.elements.length / 2));
    }

    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int currentIndex = size - 1;

            @Override
            public boolean hasNext() {
                return currentIndex >= 0;
            }

            @Override
            public E next() {
                if (!hasNext()) {
                    throw new UnsupportedOperationException();
                }
                return (E) elements[currentIndex--];
            }
        };
    }

    private void ensureIndex(int index) {
        if (index < 0 || index >= this.size) {
            throw new IndexOutOfBoundsException("Index is out of bounds.");
        }
    }
}
