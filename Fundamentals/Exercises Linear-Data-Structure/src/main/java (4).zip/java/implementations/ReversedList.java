package implementations;

import java.util.Arrays;
import java.util.Iterator;

public class ReversedList<E> implements Iterable<E> {
    private static final int INITIAL_DEFAULT_CAPACITY = 2;
    private static final int CAPACITY_INCREASE_FACTOR = 2;

    private static final String INDEX_OUT_OF_BOUNDS_MESSAGE = "Index is out of bounds!";

    private E[] elements;
    private int capacity;
    private int size;

    public ReversedList() {
        capacity = INITIAL_DEFAULT_CAPACITY;
        this.elements = (E[]) new Object[capacity];
    }

    public boolean add(E element) {
        if (this.size < capacity()) {
            grow();
        }
        this.elements[size++] = element;
        return true;
    }

    public E get(int index) {
        if (!isValidIndex(index)) {
            throw new IndexOutOfBoundsException(INDEX_OUT_OF_BOUNDS_MESSAGE);
        }
        return this.elements[getReversedIndex(index)];
    }

    public E removeAt(int index) {
        if (!isValidIndex(index)) {
            throw new IndexOutOfBoundsException(INDEX_OUT_OF_BOUNDS_MESSAGE);
        }

        int wat = getReversedIndex(index);
        E removedValue = this.elements[getReversedIndex(index)];
        shiftLeft(getReversedIndex(index));
        size--;
        return removedValue;
    }

    public int size() {
        return this.size;
    }

    public int capacity() {
        return this.capacity;
    }

    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int indexCounter = size - 1;

            @Override
            public boolean hasNext() {
                return indexCounter >= 0;
            }

            @Override
            public E next() {
                return elements[indexCounter--];
            }
        };
    }

    private boolean isEmpty() {
        return size == 0;
    }



    private void increaseCapacity() {
        capacity *= CAPACITY_INCREASE_FACTOR;
    }

    private void grow() {
        if (size()<capacity()) {
            increaseCapacity();
            this.elements = Arrays.copyOf(this.elements, capacity);
        }
    }

    private void shiftLeft(int fromIndex) {
        for (int i = fromIndex; i < size - 1; i++) {
            this.elements[i] = this.elements[i + 1];
        }
    }

    private boolean isValidIndex(int index) {
        return index >= 0 && index < size;
    }


    private int getReversedIndex(int index) {
        return size - 1 - index;
    }

}